# Simple Traffic ML Project
Ready for GitHub upload.